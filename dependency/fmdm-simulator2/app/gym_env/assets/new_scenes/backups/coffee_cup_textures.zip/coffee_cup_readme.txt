
Polygon model of Disposable coffee cup - PBR

Available in three different formats.

Blender .blend ,  FBX and OBJ.

Software used: Blender 2.9, Krita & Substance Painter

Texture Maps: Base Color, Metallic, Normal and Roughness

UV Mapped - Yes 
Overlapping UVs - No

Faces Count  : 9824
Vertex Count  : 9989

Renderer   : Blender Cycles

..........................

Can be used commercially with credits.
Content not for redistribution.
For more details visit:
www.animatedheaven.weebly.com

